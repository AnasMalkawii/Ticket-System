package com.mysecurity.auth.exception.api;

import com.mysecurity.auth.exception.api.base.ApiException;
import org.springframework.http.HttpStatus;

public class DuplicateUsernameException extends ApiException {
    public DuplicateUsernameException() {
        super("Username already exists", HttpStatus.CONFLICT);
    }
}
