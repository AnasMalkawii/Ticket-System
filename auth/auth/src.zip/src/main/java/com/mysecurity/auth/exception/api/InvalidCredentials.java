package com.mysecurity.auth.exception.api;

import com.mysecurity.auth.exception.api.base.ApiException;
import org.springframework.http.HttpStatus;

public class InvalidCredentials extends ApiException {
    public InvalidCredentials() {
        super("Invalid Credentials", HttpStatus.BAD_REQUEST);
    }
}
