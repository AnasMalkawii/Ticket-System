package com.mysecurity.auth.exception.api;

import com.mysecurity.auth.exception.api.base.ApiException;
import org.springframework.http.HttpStatus;

public class InvalidToken extends ApiException {
    public InvalidToken() {
        super("Invalid Token", HttpStatus.UNAUTHORIZED);
    }
}
