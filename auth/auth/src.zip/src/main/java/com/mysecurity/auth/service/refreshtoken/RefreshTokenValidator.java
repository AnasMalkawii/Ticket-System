package com.mysecurity.auth.service.refreshtoken;


import com.mysecurity.auth.dto.refresh.TokenValidationResult;
import com.mysecurity.auth.entity.RefreshToken;
import com.mysecurity.auth.entity.User;
import com.mysecurity.auth.enums.TokenType;
import com.mysecurity.auth.exception.api.*;
import com.mysecurity.auth.jwt.core.JwtService;
import com.mysecurity.auth.repository.RefreshTokenRepository;
import com.mysecurity.auth.repository.UserRepository;
import com.mysecurity.auth.util.TokenHash;
import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class RefreshTokenValidator {
    private final RefreshTokenService refreshTokenService;
    private final RefreshTokenRepository refreshTokenRepository;
    private final JwtService jwtService;
    private final UserRepository userRepository;

    public TokenValidationResult validate(String refreshToken) {
        try {

            if (refreshToken == null || refreshToken.isBlank()) {
                throw new MissingTokenException();
            }
            Claims claims = jwtService.extractAllClaims(refreshToken, TokenType.REFRESH);
            String username = claims.getSubject();
            Long id = Long.parseLong(claims.getId());
            User user = userRepository.findByUsername(username).orElseThrow(UserNotFoundException::new);

            if (!jwtService.isTokenValid(refreshToken, user, TokenType.REFRESH)) {
                throw new InvalidToken();
            }


            RefreshToken storedRefreshToken = refreshTokenRepository.findById(id).orElseThrow(InvalidToken::new);


            if (storedRefreshToken.isRevoked()) {
                throw new RevokedToken();
            }

            String hashedRawToken = TokenHash.hash(refreshToken);
            if (!hashedRawToken.equals(storedRefreshToken.getTokenHash())) {
                throw new InvalidToken();
            }

            if (!storedRefreshToken.getUser().getId().equals(user.getId())) {
                throw new InvalidToken();
            }


            return new TokenValidationResult(user, storedRefreshToken, id);
        } catch (RuntimeException e) {
            throw new ExpiredTokenException();
        }
    }
}
