package com.mysecurity.auth.service.refreshtoken;

import com.mysecurity.auth.dto.refresh.RefreshResponse;
import com.mysecurity.auth.dto.refresh.TokenValidationResult;
import com.mysecurity.auth.entity.RefreshToken;
import com.mysecurity.auth.entity.User;
import com.mysecurity.auth.enums.TokenType;
import com.mysecurity.auth.exception.api.MissingTokenException;
import com.mysecurity.auth.jwt.core.JwtService;
import com.mysecurity.auth.repository.RefreshTokenRepository;
import com.mysecurity.auth.util.TokenExtractor;
import com.mysecurity.auth.util.TokenIssuer;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
@RequiredArgsConstructor
public class RefreshTokenService {
    private final RefreshTokenRepository refreshTokenRepository;
    private final JwtService jwtService;

    public RefreshToken createAndSaveRefreshToken(User user, String deviceIp) {
        RefreshToken refreshToken = RefreshToken.builder()
                .user(user)
                .deviceIp(deviceIp)
                .createdAt(Instant.now())
                .expiresAt(Instant.now().plusMillis(jwtService.extractTokenExpiration(TokenType.REFRESH)))
                .build();

        return refreshTokenRepository.save(refreshToken);

    }

    public boolean isRevoked(Long id){
        return refreshTokenRepository.findById(id).map(RefreshToken::isRevoked).orElse(true);
    }

    public void revokeRefreshToken(Long id) {
        refreshTokenRepository.findById(id).ifPresent( token -> {
            token.setRevoked(true);
            refreshTokenRepository.save(token);
        });
    }



}
