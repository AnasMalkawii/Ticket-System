package com.mysecurity.auth.exception.api;

import com.mysecurity.auth.exception.api.base.ApiException;
import org.springframework.http.HttpStatus;

public class ExpiredTokenException extends ApiException {
    public ExpiredTokenException() {
        super("Token is Expired ", HttpStatus.UNAUTHORIZED);
    }
}
