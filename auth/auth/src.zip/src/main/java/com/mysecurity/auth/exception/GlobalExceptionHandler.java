package com.mysecurity.auth.exception;

import com.mysecurity.auth.exception.api.base.ApiException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


import java.time.Instant;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ApiException.class)
    public ResponseEntity<ErrorResponse> handleApiException(ApiException e) {
        HttpStatus httpStatus = e.getHttpStatus();

        ErrorResponse errorResponse = ErrorResponse.of(e.getMessage(), httpStatus.value(), httpStatus.name(), Instant.now());

        return ResponseEntity.status(e.getHttpStatus()).body(errorResponse);

    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ErrorResponse> handleAccessDeniedException(AccessDeniedException e) {
        HttpStatus httpStatus = HttpStatus.UNAUTHORIZED;
        String message = e.getMessage();

        ErrorResponse errorResponse = ErrorResponse.of(message, httpStatus.value(), httpStatus.name(), Instant.now());


        return ResponseEntity.badRequest().body(errorResponse);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationExceptions(MethodArgumentNotValidException ex) {

        String message = ex.getBindingResult().getFieldErrors().stream()
                .findFirst()
                .map(error -> error.getField() + ": " + error.getDefaultMessage())
                .orElse("Validation error");

        ErrorResponse errorResponse = ErrorResponse.of(message, HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.name(), Instant.now());


        return ResponseEntity.badRequest().body(errorResponse);
    }


    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGlobalException(Exception e) {

        String message = e.getMessage();

        ErrorResponse errorResponse = ErrorResponse.of(message, HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.name(), Instant.now());


        return ResponseEntity.internalServerError().body(errorResponse);
    }
}
