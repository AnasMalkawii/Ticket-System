package com.mysecurity.auth.exception.api;

import com.mysecurity.auth.exception.api.base.ApiException;
import org.springframework.http.HttpStatus;

public class RevokedToken extends ApiException {
    public RevokedToken() {
        super("Token is revoked", HttpStatus.UNAUTHORIZED);
    }
}
