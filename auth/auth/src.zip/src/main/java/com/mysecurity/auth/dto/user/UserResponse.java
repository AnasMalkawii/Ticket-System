package com.mysecurity.auth.dto.user;

import com.mysecurity.auth.enums.Role;

public record UserResponse(
        String username,
        Role role
) {
}
