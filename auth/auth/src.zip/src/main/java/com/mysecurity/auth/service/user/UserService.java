package com.mysecurity.auth.service.user;

import com.mysecurity.auth.dto.user.UserResponse;
import com.mysecurity.auth.entity.User;
import com.mysecurity.auth.exception.api.UserNotFoundException;
import com.mysecurity.auth.repository.UserRepository;
import jakarta.annotation.Nonnull;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;

    public UserResponse getUser() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();

        return userRepository.findByUsername(username).map(user -> new UserResponse(
                user.getUsername(),
                user.getRole()
        )).orElseThrow(UserNotFoundException::new);

    }

    public UserResponse getUserAdmin() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();

        return userRepository.findByUsername(username).map(user -> new UserResponse(
                user.getUsername(),
                user.getRole()
        )).orElseThrow(UserNotFoundException::new);

    }

}
